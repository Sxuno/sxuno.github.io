# This file is part of Blender WebGPU Export.
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE.txt for details.

from __future__ import annotations

import pathlib
import shutil
import json

# Development flags
FLAG_EXPERIMENTAL 				= 1 << 1
FLAG_DEVELOPMENT 				= 1 << 2
FLAG_DEBUG						= 1 << 3
FLAG_FORCED_CONTENT_CLEANUP		= 1 << 4

FLAGS = FLAG_DEVELOPMENT | FLAG_EXPERIMENTAL

# Axis Mapping (Blender to WebGPU Engine)
#
# Default Mapping (Recommended):
# ------------------------------
# Location:             x, y, z
# Rotation (Euler XYZ): -x, -y, -z  // Negate all Euler angles

# TYPES
# TODO: Rething object vs type may use type and lighttype to avoid namespace object in python
class Camera:
	"""
	**📎 Documentation:** *webgpu/types.md*  

	Keyword Arguments:
		name        	= str
		object(type)	= str
		location    	= vec3
		rotation    	= vec3 radian
		scale       	= vec3
	"""
	def __init__(self, **kwargs):
		self.name = ''
		self.object = ''
		self.location = []
		self.rotation = []
		self.scale = []
		for key, value in kwargs.items():
			setattr(self, key, value)
class Mesh:
	"""
	**📎 Documentation:** *webgpu/types.md*  

	Keyword Arguments:
		name                = str
		object(type)		= str
		location            = vec3
		rotation            = vec3 radian
		scale               = vec3
		vertices            = [float]
		vertex_materials    = [int]
		indices             = [int]
		materials           = [str]
		uv_coords			= [vec2]
		normals             = [vec3]
		edges               = [vec2]
	"""
	def __init__(self, **kwargs):
		self.name = ''
		self.object = ''
		self.location = []
		self.rotation = []
		self.scale = [] 
		self.vertices = []
		self.vertex_materials = []
		self.indices = []
		self.materials = []
		self.uv_coords = []
		self.normals = []
		self.edges = []
		for key, value in kwargs.items():
			setattr(self, key, value)
class Material:
	"""
	**📎 Documentation:** *webgpu/types.md*  

	Keyword Arguments:
		name        	= str
		object(type)	= str
		rgb         	= [vec3]
		culling			= bool
	"""
	def __init__(self, **kwargs):
		self.name = ''
		self.object = ''
		self.rgb = []
		self.culling = False
		for key, value in kwargs.items():
			setattr(self, key, value)
class Light:
	"""
	**📎 Documentation:** *webgpu/types.md*  
	
	Keyword Arguments:
		name        	= str
		object(type)	= str
		type        	= str
		color			= vec3
		location    	= vec3
		rotation    	= vec3 radian
		scale       	= vec3
		power			= float
		distance		= float
	"""
	def __init__(self, **kwargs):
		self.name = ''
		self.object = ''
		self.type = ''
		self.color = []
		self.location = []
		self.rotation = []
		self.scale = []
		self.power = 0.0
		self.distance = 0.0
		for key, value in kwargs.items():
			setattr(self, key, value)
# DATAOBJECT
class Scene:
	pass
	class Data:
		def __init__(self, **kwargs):
			self.cameras   = [Camera(**camera) if isinstance(camera, dict) else camera for camera in kwargs.get('cameras', [])]
			self.meshes    = [Mesh(**mesh) if isinstance(mesh, dict) else mesh for mesh in kwargs.get('meshes', [])]
			self.materials = [Material(**material) if isinstance(material, dict) else material for material in kwargs.get('materials', [])]
			self.lights    = [Light(**light) if isinstance(light, dict) else light for light in kwargs.get('lights', [])]
# ADDON OPTIONS
class Colormanagment:
	def __init__(self, **kwargs):
		self.tonemap = ''
		self.look = ''
		self.exposure = ''
		self.gamma = ''
		for key, value in kwargs.items():
			setattr(self, key, value)
class Viewport:
	def __init__(self, **kwargs):
		self.camera = ''
		self.color = ''
		self.transperancy = ''
		self.resolution = []
		self.colormanagment = Colormanagment()
		for key, value in kwargs.items():
			if key == 'colormanagment' and isinstance(value, dict):
				self.colormanagment = Colormanagment(**value)
			else:
				setattr(self, key, value)
class Options:
	"""
	**📎 Documentation:** *webgpu/options.md*  

	Represents export options for the WebGPU exporter.
	"""
	def __init__(self, **kwargs):
		self.filename = ''
		self.filepath = ''
		self.overwrite = True
		self.distribution = ''
		self.template = ''
		self.viewport = Viewport()
		for key, value in kwargs.items():
			if key == 'viewport' and isinstance(value, dict):
				self.viewport = Viewport(**value)
			else:
				setattr(self, key, value)
# FILE LOGIC
class Files:
	class Html:
		@staticmethod
		def generate(options: Options):
			"""
			**📎 Documentation:** *webgpu/templates.md*  

			generate blob from template.format()
			"""
			template = pathlib.Path(__file__).parent / 'template' / options.template.lower() / f'{options.template.lower()}.html'
			# TODO: update for dynamic attribute instructions
			blob = template.read_text(encoding='utf-8').format(
				filename = options.filename,
				camera = options.viewport.camera,
				# TODO: Use width and height for resolution scale? may move to css to free inline overwrite
				width = options.viewport.resolution[0], 
				height = options.viewport.resolution[1],
				resolution = '{}, {}'.format(*options.viewport.resolution),
			)
			return blob
		@classmethod
		def create(cls, context: Scene.Data, options: Options):
			with open(options.filepath / f'{options.filename}.html', 'w', encoding='utf-8') as target:
				target.write(cls.generate(options))
	class CSS:
		@staticmethod
		def generate(options: Options):
			"""
			**📎 Documentation:** *webgpu/templates.md*  

			generate blob from template.format()
			"""
			template = pathlib.Path(__file__).parent / 'template' / options.template.lower() / f'{options.template.lower()}.css'
			# Placeholder for Z-Index Configuration and HTMLElement Bindings
			blob = template.read_text(encoding = 'utf-8') #.format()
			return blob
		@classmethod
		def create(cls, context: Scene.Data, options: Options):
			with open(options.filepath / f'{options.filename}.css', 'w', encoding='utf-8') as target:
				target.write(cls.generate(options))
	class Engine:
		@staticmethod
		def generate(options: Options):
			"""
			**📎 Documentation:** *webgpu/shaders.md*  
			"""
			# DATA
			shaders = [pathlib.Path(__file__).parent / 'engine' / 'shader']
			collection = []
			for path in shaders:
				for entry in path.iterdir():
					if entry.is_dir() and entry not in shaders:
						shaders.append(entry)
					if entry.is_file():
						if entry.parent == shaders[0]:
							continue
						folders = entry.parent.relative_to(shaders[0]).parts
						group = next((item for item in collection if item['name'] == folders[0]), None)
						if not group:
							collection.append({'name': folders[0], 'file': [entry.stem], 'path': [entry.parent.relative_to(pathlib.Path(__file__).parent)], 'blob': []})
						else:
							group['path'].append(entry.parent.relative_to(pathlib.Path(__file__).parent))
							group['file'].append(entry.stem)
			# DATA SERIALIZATION
			blobs = {'name': [], 'data': []}
			import re as parser
			for group in collection:
				license = None
				namespaceset = set()
				context = []
				for index in range(len(group['file'])):	
					namespaces = []				
					shader = ''
					source = (pathlib.Path(__file__).parent / str(group['path'][index] / str(group['file'][index] + '.wgsl'))).read_text(encoding = 'utf-8')
					match = parser.match(r'^(/\* License[\s\S]*?\*/\s*\n?)', source)
					if match:
						if license == None:
							license = match.group(0)
						code = source[len(license):]
					else:
						if license == None:
							license = ''
						code = source
					nameparts = group['path'][index].parts
					namespace = nameparts[0]
					for name in nameparts[1:]:
						namespace += f'.{name}'
						if f"{namespace} = {namespace} || {{}}\n" not in namespaceset:
							namespaceset.add(f"{namespace} = {namespace} || {{}}\n")
							namespaces.append(f"{namespace} = {namespace} || {{}}\n")
					shader = f"{namespace}.{group['file'][index]} = `\n{code}`\n"
					context.append(''.join(namespaces))
					context.append(shader)
				blobs['name'].append(group['name'])
				group['blob'].append(license)
				group['blob'].append(''.join(context))
				blobs['data'].append(''.join(group['blob']))
			return blobs
		@classmethod
		def create(cls, context: Scene.Data,options: Options):
			engine = [pathlib.Path(__file__).parent / 'engine']
			for path in engine:
				(pathlib.Path(options.filepath) / path.relative_to(pathlib.Path(__file__).parent)).mkdir(parents = True, exist_ok = True)
				for entry in path.iterdir():
					if entry.is_dir() and entry not in engine:
						if 'shader\\' not in str(entry) and 'shader/' not in str(entry):							
							engine.append(entry)
						else:
							blobs = cls.generate(options)
							(pathlib.Path(options.filepath) / 'engine' / 'shader').mkdir(parents = True, exist_ok = True)
							for index in range(len(blobs['name'])):
								with open(options.filepath / 'engine' / 'shader' / (blobs['name'][index] + '.js'), 'w', encoding = 'utf-8') as target:
									target.write(blobs['data'][index])
					if entry.is_file():
						shutil.copy(entry, pathlib.Path(options.filepath) / entry.relative_to(pathlib.Path(__file__).parent))
	class Content:
		@staticmethod
		def generate(context: Scene.Data, options: Options):
			"""
			Generate a scene data from converted Blender data.
			Args:
				context (webgpu.Scene.Data): Converted Blender data.
				options (webgpu.Options): Addon Options.
			"""
			# TODO: combine fallback and remapping into one loop for preformance
			# default engine material (internal fallback with overwrite)
			default_engine_material = next((index for index, material in enumerate(context.materials) if material.name == 'engine_default'), None)
			if default_engine_material is not None:
				default_engine_material_overwrite = context.materials.pop(default_engine_material)
				context.materials.insert(0, default_engine_material_overwrite)
			else:
				context.materials.insert(0, Material(name = 'engine_default', object='material', rgb = (1.0, 0.0, 1.0), culling = False))
			# Micro optimization: replace str with int (index remapping)
			if context.meshes:
				index_map = {material.name: index for index, material in enumerate(context.materials)}
				for mesh in context.meshes:
					if mesh.materials:
						for index, name in enumerate(mesh.materials):
							mesh.materials[index] = index_map[name]
			# SERIALIZER
			blobs = {
				'info':{
					'data': {
						'filepath': [],
					},
					'blob': None,
				}, 
				'files': {'blob': [],}
			}
			for name, group in vars(context).items():
				if not group:
					continue
				for obj in group:
					attributes = []
					for attribute, value in vars(obj).items():
						if isinstance(value, (bool)):
							values = str(value).lower()
						elif isinstance(value, (list, tuple)):
							values = json.dumps(list(value), separators = (',',':'))
						elif isinstance(value, (int, float)):
							values = str(value)
						else:
							values = f"'{value}'"
						attributes.append(f"{attribute}:{values}")
					datablock = ",".join(attributes)
					blobs['files']['blob'].append(f"engine.scene.cache={{{datablock}}}")
					filename = getattr(obj, 'name')
					blobs['info']['data']['filepath'].append(f"{name}/{filename}")
			# INFO BLOB
			# TODO: rethink updated version
			blobs['info']['blob'] = (
				f"engine.scene.info.push({{" +
				f"\n\t'name':'{options.filename}'," +
				f"\n\t'camera':'{options.viewport.camera}'," +
				f"\n\t'viewport':{{" +
				f"\n\t\t'color':{list(options.viewport.color)}," +
				f"\n\t\t'alpha':{str(options.viewport.transperancy).lower()}," +
				f"\n\t}}," +
				f"\n\t'files':[\n\t\t" +
				",\n\t\t".join(f"'{path}'" for path in blobs['info']['data']['filepath']) +
				f"\n\t]," +
				f"\n}})"
			)
			return blobs
		@classmethod
		def create(cls, context: Scene.Data, options: Options):
			"""
			creates file from generated blob data.
			"""
			match options.distribution:
				case 'SERVER' | 'Server':
					ext = '.js'
				case 'STANDALONE' | 'Standalone':
					ext = '.js'
				case _: 
					print(f'Error: distribution {options.distribution} is missing file extension')
			# FORCED CONTENT CLEANUP		
			if FLAGS & FLAG_FORCED_CONTENT_CLEANUP:
				if (pathlib.Path(options.filepath / 'content')).exists():
					shutil.rmtree(pathlib.Path(options.filepath / 'content'))
			# content file creation
			blobs = cls.generate(context, options)
			filepaths = blobs['info']['data']['filepath']
			for key, item in blobs.items():
				if key == 'info':
					if not options.overwrite and (pathlib.Path(options.filepath) / 'content/info.js').exists():
						item['blob'] = (pathlib.Path(options.filepath) / 'content/info.js').read_text(encoding = 'utf-8')+'\n'+item['blob']
					(pathlib.Path(options.filepath) / 'content').mkdir(parents = True, exist_ok = True)
					with open(options.filepath / 'content/info.js', 'w', encoding = 'utf-8') as target:
						target.write(item['blob'])
				if key == 'files':
					for index, blob in enumerate(item['blob']):
						filepath = filepaths[index] + ext
						(pathlib.Path(options.filepath) / 'content' / pathlib.Path(filepath).parent).mkdir(parents = True, exist_ok = True)
						if not options.overwrite and (pathlib.Path(options.filepath) / 'content' / filepath).exists():
							continue
						with open(options.filepath / 'content' / filepath, 'w', encoding = 'utf8') as target:
							target.write(blob)
	@classmethod
	def create(cls, context: Scene.Data, options: Options):
		for _, file in cls.__dict__.items():
		   if isinstance(file, type):
			   file.create(context, options)
def generate(context: Scene.Data, options: Options):
	"""
	**📎 Documentation:** *webgpu/generate.md*  
	Args:
		context (webgpu.Scene.Data): converted Scene Data object.
		options (webgpu.Options): Configuration options instance.
	"""
	Files.create(context, options)
def register():
	print(f'{__name__}')
def unregister():
	pass