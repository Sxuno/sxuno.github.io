/* License
 * This file is part of WebGPU-Engine.
 * Licensed under the GNU General Public License v3.0 or later.
 * See LICENSE.txt for details.
 */
@vertex
fn main(@builtin(vertex_index) idx : u32) -> @builtin(position) vec4f {
    var uv = vec2f(f32((idx << 1) & 2), f32(idx & 2));
    return vec4f(uv * 2.0 - 1.0, 0.0, 1.0);
}