/* License
 * This file is part of WebGPU-Engine.
 * Licensed under the GNU General Public License v3.0 or later.
 * See LICENSE.txt for details.
 */
struct VertexOut {
    @builtin(position) Position : vec4<f32>,
    @location(0) color : vec4<f32>,
};

fn tonemap(x: vec3<f32>) -> vec3<f32> {
    // Khronos neutral (AgX) tonemapper
    let A = 0.22;
    let B = 0.30;
    let C = 0.10;
    let D = 0.20;
    let E = 0.01;
    let F = 0.30;

    let numerator = x * (A * x + C * B) + D * E;
    let denominator = x * (A * x + B) + D * F;
    let result = (numerator / denominator) - (E / F);

    return clamp(result, vec3<f32>(0.0), vec3<f32>(1.0));
}

fn toSRGB(rgb: vec3<f32>) -> vec3<f32> {
    return pow(rgb, vec3<f32>(1.0 / 2.2));
}

@fragment
fn main(input: VertexOut) -> @location(0) vec4<f32> {
    let linear = input.color.rgb;
    let agxColor = tonemap(linear);
    let finalColor = toSRGB(agxColor);
    return vec4<f32>(finalColor, input.color.a);
}