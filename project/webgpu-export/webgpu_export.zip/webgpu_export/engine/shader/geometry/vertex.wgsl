/* License
 * This file is part of WebGPU-Engine.
 * Licensed under the GNU General Public License v3.0 or later.
 * See LICENSE.txt for details.
 */
struct Metadata {
    viewProj: mat4x4<f32>,
    canvasSize: vec2<f32>,
    lightNum: f32,
    background: vec4<f32>
};

@group(0) @binding(0) var<uniform> metadata : Metadata;
@group(0) @binding(1) var<storage, read> modelMatrices : array<mat4x4<f32>>;
@group(0) @binding(2) var<storage, read> materialSlot      : array<u32>;
@group(0) @binding(3) var<storage, read> materialSlotOffset: array<u32>;
@group(0) @binding(4) var<storage, read> materials: array<vec4<f32>>;

struct VertexIn {
	@location(0) position        : vec3<f32>,
	@location(1) vertexMaterial  : u32,
};

struct VertexOut {
	@builtin(position) Position : vec4<f32>,
	@location(0) color : vec4<f32>,
};

@vertex
fn main(input: VertexIn, @builtin(vertex_index) vertexIndex: u32, @builtin(instance_index) instanceIndex: u32) -> VertexOut {
    var out : VertexOut;

	let model : mat4x4<f32> = modelMatrices[instanceIndex];
	out.Position = metadata.viewProj * (model * vec4<f32>(input.position, 1.0));
    out.color = materials[materialSlot[materialSlotOffset[instanceIndex]]];

	return out;
}