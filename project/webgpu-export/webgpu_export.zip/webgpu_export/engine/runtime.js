/*
 * This file is part of WebGPU-Engine.
 * Licensed under the GNU General Public License v3.0 or later.
 * See LICENSE.txt for details.
 */

engine.runtime = (function () {
	
	// =======
	// PRIVATE
	// =======

	// CONTEXT INTERNAL
	let _canvas
	let _visibility
	// FRAME
	let _frameID
	// OLD
	let _device = null
	let _format = null
	let _context = null

	/* 2252 observer */ // TODO: add func integration
	let observer = {
		init : async function() {
			return new Promise(resolve => {
				if (!_canvas) {resolve()}
				let _resize = false
				let _intersect = false
				const resolver = () => {if(_resize && _intersect)resolve()}
				observer.resize = new ResizeObserver(entries => {
					for (const entry of entries) {
						engine.debug?.log(`Canvas ID ${_canvas.findIndex(element => element === entry.target)} size: ${entry.contentRect.width} x ${entry.contentRect.height}`) // DEBUG Datapoints
					} 
					_resize = true
					resolver()
				})
				observer.intersect = new IntersectionObserver(entries => {
					let canvasID
					for(const index in entries) {
						canvasID = _canvas.findIndex(element => element === entries[index].target)
						if(canvasID != -1) {
							engine.debug?.log(`Canvas ID ${canvasID} ${entries[index].isIntersecting ? 'visible' : 'hidden'}`)
							_visibility[canvasID] = entries[index].isIntersecting
						}
					}
					_intersect = true
					resolver()
				})
				_canvas.forEach(element => {
					observer.intersect.observe(element)
					observer.resize.observe(element)
				})
			})
		},
		intersect : null,
		resize : null,
	}

	// ======
	// PUBLIC
	// ======

	const init = (function() {
		// INIT
		engine.log.info('init runtime')
		// SOA PREALOCATION
		_canvas = Array.from(document.querySelectorAll('canvas'))
		_visibility = new Array(_canvas.length).fill(null) // int16Array? drawback runtime context init needs rebuild

		async function loadhandler(device, format) {
			// CONTEXT LOADER
			await observer.init()
			// OLD
			_device = device
			_format = format
			_context = engine.gpu.context[0]
			
			engine.debug?.start('load scene')

			await engine.scene.init()
			for (let index in engine.gpu.context) {
				await engine.scene.load(engine.gpu.context[index].config.scene)
			}
			/* TODO: rethink scene graph in multiscene support context */
				await engine.scene.graph.init()
				/* 
					scene info frame (controlled by runtime renderer #second.(framenumber per second or keyframe size))
					scene info delta (controlled by runtime logic #timeline #keyframes)
					scene info buffer (lookup throug index arry?)
						buffer lifetime = gpu.buffer.get(context) buffer throu context? or scene?
					execution:
						get sences by name
							check frame delta
						per dif create buffers and call pipline
				*/
			engine.debug?.end('load scene')

			engine.debug?.start('pass init')
			/* TODO: make it data driven and context dependend instead of 'giving' context,
					may move to  core.js > pipeline init (dose not exist yet) 
					batch switch 
						per pipline # synced framerequest 
						per context # individual framerequest
					*/
				await engine.pipeline.depthpass.init(_device, _context)
				await engine.pipeline.basepass.init(_device, _context)
				await engine.pipeline.shadowpass.init(_device, _context)
				await engine.pipeline.lightpass.init(_device, _context)
				await engine.pipeline.composepass.init(_device, _context)

			engine.debug?.end('pass init')

			/* TODO: add 'frame bindings' init call method,
					for privatscope DOM update scheduling */

			requestAnimationFrame(frame)
		}
		return loadhandler
	})()



	function frame() {
		engine.STATS.frametime = performance.now() - engine.STATS.delta
		engine.STATS.delta = performance.now()

		const encoder = _device.createCommandEncoder()
		// Defered Drawcalls
		engine.pipeline.depthpass.draw(_device, _context)
		engine.pipeline.basepass.draw(encoder)
		engine.pipeline.shadowpass.draw(encoder)
		engine.pipeline.lightpass.draw(encoder)
		engine.pipeline.composepass.draw(encoder, _context)

		_device.queue.submit([encoder.finish()])

		_frameID = requestAnimationFrame(frame)
	}

	// ======
	// EXPORT
	// ======

	// DECLARE VAR
	let runtime = {init}
	// IF FEATURESET VAR.FEATURE
	// RETURN VAR
	return runtime
})()