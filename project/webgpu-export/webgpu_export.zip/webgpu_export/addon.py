# This file is part of Blender WebGPU Export.
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE.txt for details.

from __future__ import annotations

import bpy
import bpy_extras
import bpy_extras.io_utils

import pathlib

def camera_names(self, context):
	items = []
	for entry in bpy.context.scene.objects:
		if entry.type == 'CAMERA':
			items.append((entry.name, entry.name, 'Camera object'))
	if not items:
		if bpy.context.scene.camera:
			items = [(bpy.context.scene.camera.name, bpy.context.scene.camera.name, '')]
		else:
			items = [('NONE', 'None', '')]
	return items

# scene filter flags
INCLUDE_SELECTED = 1 << 0
INCLUDE_VISIBLE = 1 << 1
INCLUDE_COLLECTION = 1 << 2
INCLUDE_MODIFIRE = 1 << 3

def filtered_scene(filter: int = 0):
	if filter == 0:
		return bpy.context.scene.objects
	scene = []
	for obj in bpy.context.scene.objects:        
		if (filter & INCLUDE_SELECTED) and not obj.select_get():
			continue
		if (filter & INCLUDE_VISIBLE) and not obj.visible_get():
			continue
		if (filter & INCLUDE_COLLECTION) and obj.name not in bpy.context.view_layer.active_layer_collection.collection.objects:
			continue
		scene.append(obj)
	return scene

# Axis Mapping (Blender to WebGPU Engine)
# ------------------------------
# Location:                   x, y, z
# Rotation:
#    Meshes 	         Euler x, y, z
#    Cameras     Negativ Euler z, y, x 

class WEBGPU_CONV_Cameras(list):
	def __init__(self, filter = 0, SelectedCamera: str = None):
		super().__init__()
		from .webgpu import Camera
		cameras = []
		for entry in filtered_scene(filter):
			if entry.type == 'CAMERA':
				cameras.append(entry)
		if not any(camera.name == SelectedCamera for camera in cameras): # fallback to selected camera if none is in fildered_scene
			cameras.append(bpy.data.objects.get(SelectedCamera))
		for obj in cameras:
			self.append(Camera(
				name = obj.name,
				object = obj.type.lower(),
				location = obj.location[:],
				rotation = [-value for value in obj.rotation_euler.to_matrix().to_euler('ZYX')[:]], # Axismapping rotation negation
				scale = obj.scale[:],
				near = obj.data.clip_start,
				far = obj.data.clip_end,
			))

class WEBGPU_CONV_Meshes(list):
	def __init__(self, filter = 0):
		super().__init__()
		from .webgpu import Mesh
		depsgraph = bpy.context.evaluated_depsgraph_get()
		for obj in filtered_scene(filter):
			if obj.type == 'MESH':
				if obj.data.vertices:
					if not filter & INCLUDE_MODIFIRE: # TODO: Invert after adding prop_modifire
						# Apply Modifire
						obj_eval = depsgraph.id_eval_get(obj)
						try:
							geometry = obj_eval.evaluated_geometry()
							mesh = geometry.mesh
						except:
							mesh = obj_eval.to_mesh(preserve_all_data_layers=True, depsgraph=depsgraph)
							bpy.ops.wm.report({'window': bpy.context.window}, type='INFO', message='Legacy Mesh data')
					else:
						mesh = obj.data
						if not mesh.loop_tirangles:
							mesh.calc_loop_triangles()
					# Webgpu Type Instance
					self.append(Mesh(
						name = obj.name,
						object = obj.type.lower(),
						location = obj.location[:],
						rotation = obj.rotation_euler.to_matrix().to_euler('XYZ')[:], 
						scale = obj.scale[:],
						vertices = [coord for vertex in mesh.vertices for coord in vertex.co],
						indices = [vertex for tris in mesh.loop_triangles for vertex in tris.vertices],
						vertex_materials = [tris.material_index for tris in mesh.loop_triangles],
						materials = [slot.material.name if slot.material else '' for slot in obj.material_slots],
						# staged for later texutresupport
						# uv_coords = [coord for tris in mesh.loop_triangles for loop_index in tris.loops for coord in (mesh.uv_layers.active.data[loop_index].uv if mesh.uv_layers.active else (0.0, 0.0))]           
					))
					if isinstance(mesh, bpy.types.Mesh) and mesh != obj_eval.data:
						obj_eval.to_mesh_clear()

class WEBGPU_CONV_Materials(list):
	def __init__(self, filter = 0):
		super().__init__()
		from .webgpu import Material
		for obj in filtered_scene(filter):
			if obj.type == 'MESH':
				for slot in obj.material_slots:
					if slot.material is None or any(material.name == slot.material.name for material in self):
						continue 
					self.append(Material(
						name = slot.material.name,
						object = 'material',
						rgb = (next((node.inputs['Base Color'].default_value[:3] for node in slot.material.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'), (1.0, 0.0, 1.0)) if slot.material.use_nodes else slot.material.diffuse_color[:3]),
						culling = slot.material.use_backface_culling,
					)) 

class WEBGPU_CONV_Lights(list):
	def __init__(self, filter=0):
		super().__init__()
		from .webgpu import Light
		for obj in filtered_scene(filter):
			if obj.type == 'LIGHT':
				self.append(Light(
					name = obj.name,
					object = obj.type.lower(),
					type = obj.data.type,
					color = obj.data.color[:],
					location = obj.location[:],
					rotation = obj.rotation_euler.to_matrix().to_euler('XYZ')[:],
					scale = obj.scale[:],
					power = obj.data.energy,
					distance = getattr(obj.data, 'cutoff_distance', 7.5) # TODO: impliment fallback to engine.settings default lightcuttof
				))

class WEBGPU_CONV_Font(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_CONV_Empty(list):
	def __init__(self, filter=0):
		super().__init__()    

class WEBGPU_CONV_Pointcloud(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_CONV_Particlesystem(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_CONV_Curve(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_CONV_GPencile(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_CONV_Armature(list):
	def __init__(self, filter=0):
		super().__init__()

class WEBGPU_OT_FileExport(bpy.types.Operator, bpy_extras.io_utils.ExportHelper):
	bl_idname = 'webgpu.export'
	bl_label = 'export'
	bl_description = 'Export to Html as WebGPU'

	filename_ext = '.html'
	filter_glob: bpy.props.StringProperty(default="*.html", options={'HIDDEN'}, maxlen=255,) 
	filepath: bpy.props.StringProperty(subtype='FILE_PATH') 

	def _update_context(self, context):
		bpy.context.area.tag_redraw()

	# Properties
	show_distribution: bpy.props.BoolProperty(name='Distribution', default=True) 
	prop_distribution: bpy.props.EnumProperty(name='', description='Choose how to export', items=[('STANDALONE', 'Standalone', ''), ('SERVER', 'Server', ''),], default='STANDALONE', update=_update_context) 
	prop_content_overwrite: bpy.props.BoolProperty(name='overwrite', default=True)

	show_include: bpy.props.BoolProperty(name='Include', default=True) 
	prop_include_selected: bpy.props.BoolProperty(name='Selected Objects', default=False) 
	prop_include_visible: bpy.props.BoolProperty(name='Visible Objects', default=False) 
	prop_include_collection: bpy.props.BoolProperty(name='Active Collection', default=False) 

	show_template: bpy.props.BoolProperty(name='Template', default=True) 
	prop_template: bpy.props.EnumProperty(name='', items=[('PREVIEW', 'Preview', ''), ('SHOWCASE', 'Showcase', ''), ('BENCHMARK', 'Benchmark', '')], default='PREVIEW') 

	show_viewport: bpy.props.BoolProperty(name='Viewport', default=True) 
	prop_viewport_camera: bpy.props.EnumProperty(name='', items=camera_names, default=0)  # Blenders API expects an int if items are set dynamicly
	prop_viewport_transperancy: bpy.props.BoolProperty(name='transperency', default=False) 
	# TODO: make it template dependend.
	# prop_viewport_movement: bpy.props.EnumProperty(name='', items=[('FIXED', 'fixed', ''), ('ARCBALL', 'arcball', ''), ('WASD', 'WASD', '')], default='FIXED') 

	show_webgpu: bpy.props.BoolProperty(name='WebGPU', default=True) 
	prop_webgpu_shading: bpy.props.EnumProperty(name='', items=[('SOLID', 'Solid', ''),('WIREFRAME', 'Wireframe', '')], default='SOLID') 

	def draw(self, context):
		layout = self.layout

		layout.label(text='WebGPU Export')
		layout.label(text='Experimental Addon', icon='INFO')

		layout.prop(self, 'show_distribution', icon='TRIA_DOWN' if self.show_distribution else 'TRIA_RIGHT', emboss=False)
		if self.show_distribution:
			box = layout.box()
			box.prop(self, 'prop_distribution')
			if self.prop_distribution == 'STANDALONE':
				split = box.split(factor=0.15, align=True)
				# Left narrow icon column
				icon_col = split.column(align=True)
				icon_col.label(text='')
				icon_col.label(icon='ERROR')
				icon_col.label(text='')
				# Right wide text column
				text_col = split.column(align=True)
				text_col.label(text='Be careful with export size')
				text_col.label(text='          else switch to')
				text_col.label(text='       server distribution')
			box.label(text = 'content')
			box.prop(self, 'prop_content_overwrite')

		layout.prop(self, 'show_include', icon='TRIA_DOWN' if self.show_include else 'TRIA_RIGHT', emboss=False)
		if self.show_include:
			box = layout.box()
			box.label(text = 'Limit to')
			box.prop(self, 'prop_include_selected')
			box.prop(self, 'prop_include_visible')
			box.prop(self, 'prop_include_collection')

		layout.prop(self, 'show_template', icon='TRIA_DOWN' if self.show_template else 'TRIA_RIGHT', emboss=False)
		if self.show_template:
			box = layout.box()
			box.prop(self, 'prop_template')

		layout.prop(self, 'show_viewport', icon='TRIA_DOWN' if self.show_viewport else 'TRIA_RIGHT', emboss=False)
		if self.show_viewport:
			box = layout.box()
			box.label(text = 'Select aktive camera for scene')
			box.prop(self, 'prop_viewport_camera')
			box.label(text = 'Background')
			box.prop(self, 'prop_viewport_transperancy')
			# box.label(text='Movement')
			# box.prop(self, 'prop_viewport_movement')

		layout.prop(self, 'show_webgpu', icon='TRIA_DOWN' if self.show_webgpu else 'TRIA_RIGHT', emboss=False)
		if self.show_webgpu:
			box = layout.box()
			box.label(text='Shading')
			box.prop(self, 'prop_webgpu_shading')

	def execute(self, context):
		if self.prop_viewport_camera == 'NONE':
			def draw(menu, context):
				menu.layout.label(text="You must create a camera before exporting.")
			bpy.context.window_manager.popup_menu(draw, title="Error", icon='ERROR')
			return {'CANCELLED'}
		
		scene_filter = (lambda: (
			(INCLUDE_SELECTED if self.prop_include_selected else 0) |
			(INCLUDE_VISIBLE if self.prop_include_visible else 0) |
			(INCLUDE_COLLECTION if self.prop_include_collection else 0)
		))()
		# Setup Export
		from .webgpu import generate, Scene, Options
		generate(
			Scene.Data(
				cameras = WEBGPU_CONV_Cameras(scene_filter, self.prop_viewport_camera),
				meshes = WEBGPU_CONV_Meshes(scene_filter),
				materials = WEBGPU_CONV_Materials(scene_filter),
				lights = WEBGPU_CONV_Lights(scene_filter)
			), 
			Options(
				filename = pathlib.Path(self.filepath).stem,
				filepath = pathlib.Path(self.filepath).parent,
				overwrite = self.prop_content_overwrite,
				distribution = self.prop_distribution,
				template = self.prop_template,
				viewport = {
					'camera': self.prop_viewport_camera,
					'color': (bpy.context.scene.world.node_tree.nodes['Background'].inputs['Color'].default_value[:3] if bpy.context.scene.world and bpy.context.scene.world.use_nodes and 'Background' in bpy.context.scene.world.node_tree.nodes else bpy.context.scene.world.color[:3] if bpy.context.scene.world else (0,0,0)),
					'transperancy': (bpy.context.scene.render.film_transparent and not self.prop_viewport_transperancy) or self.prop_viewport_transperancy,
					'resolution': [bpy.context.scene.render.resolution_x, bpy.context.scene.render.resolution_y],
					'colormanagment' : {
						'tonemap' : bpy.context.scene.view_settings.view_transform,
						'look' : bpy.context.scene.view_settings.look,
						'exposure' : bpy.context.scene.view_settings.exposure,
						'gamma' : bpy.context.scene.view_settings.gamma
					}
				},
			)
		)
		print(f'Done')
		return {'FINISHED'}

	def invoke(self, context, event):
		if bpy.data.filepath:
			self.filepath = str(pathlib.Path(bpy.data.filepath).with_suffix(self.filename_ext))
		else:
			self.filepath = 'untitled' + self.filename_ext
		bpy.context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

def webgpu_menu_file_export(self, context):
	self.layout.operator(WEBGPU_OT_FileExport.bl_idname, text='Export as WebGPU (.html)')
	
def register():
	print(f'{__name__}')
	bpy.utils.register_class(WEBGPU_OT_FileExport)
	bpy.types.TOPBAR_MT_file_export.append(webgpu_menu_file_export)

def unregister():
	bpy.utils.unregister_class(WEBGPU_OT_FileExport)
	bpy.types.TOPBAR_MT_file_export.remove(webgpu_menu_file_export)