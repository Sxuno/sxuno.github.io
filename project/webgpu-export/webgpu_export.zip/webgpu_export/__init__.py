# This file is part of Blender WebGPU Export.
# Licensed under the GNU General Public License v3.0 or later.
# See LICENSE.txt for details.

bl_info = {
	'name' : 'webgpu export',
	'author' : '@Sxuno',
	'version' : (0, 1, 0),
	'blender' : (4, 5, 0),
	'location' : 'N/A',
	'description' : 'Minimal Plugin Code',
	'category' : 'Development'
}

import bpy

from . import addon
from . import webgpu

def register():
	print('\nWebGPU Export\n---\nRegister Submodules\n')
	addon.register()
	webgpu.register()
	print('')

def unregister():
	print('\nRelease Addon WebGPU Export\n')
	addon.unregister()
	webgpu.unregister()