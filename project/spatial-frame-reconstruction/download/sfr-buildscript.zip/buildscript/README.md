# SFR Builder
DEVELOPMENT BUILDSCRIPT

## requirements

- python 3.12.3+
- Pillow
- onnx
- torch 2.14.0
- torchcodec
- torchvision

***note:*** developed for cuda, cpu execution is currently not implemented.

## build

After extraction run from inside folder as working directory

```python
python SFR.py
```

## configuration

default paths
```py
PATH = {
	'input': 'input/content.png',
	'output': 'output/reconstructed.png',
	'checkpoint': 'weights/checkpoint_weights.pth',
	'model': 'model/sfr.onnx'
}
```