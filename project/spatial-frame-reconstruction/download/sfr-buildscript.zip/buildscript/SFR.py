# SFR - spatial frame reconstruction
# version = 0.1.1-dev

# -------
# CONCEPT
# -------
# methods :
	# The Mathematical Core: 1-Step Rectified Flow Matching (RFM)
	# Hardware Gating: Branchless Predication via Continuous LERP
	# Bandwidth Protection: Software-Packed FP8 (E4M3) Storage
# technique : 
	# KPN (Kernel Prediction Network) 3x3 | 5x5
# architecture : 
	# multicore syntesizer | torch workload | IO operations
	# ringbuffer layers

# TODO: edgepadding
#		namespace refactor
#		execution call wrapper

import pathlib
import torch
import torchcodec
import torchvision

DEVELOPMENT = 0
TENSOR = 0

PATH = {
	'input': 'input/content.png',
	'output': 'output/reconstructed.png',
	'checkpoint': 'weights/checkpoint_weights.pth',
	'model': 'model/sfr.onnx'
}

def hardwarecheck():
	device = 'cuda' if torch.cuda.is_available() else 'cpu'
	print(f'Hardware Target : {device.upper()}')
	if device == 'cuda':
		# print(f'Active Compute Core : {torch.cuda.get_device_name(0)}\n')
		properties = torch.cuda.get_device_properties(0)
		print(f'Device : {properties.name}')
		print(f'Memory : {properties.total_memory / 1024**3:.2f} GiB')
		print(f'SMs : {properties.multi_processor_count}')
		print(f'CUDA cores : {properties.multi_processor_count * 128}')
		print(f'Architecture : {properties.major}.{properties.minor}')
		print(f'')
		global TENSOR
		TENSOR = 1

hardwarecheck()

class Configuration:
	def __init__(self):
		properties = torch.cuda.get_device_properties
		self.hardwareTarget = 'cuda' if torch.cuda.is_available() else 'cpu'
		self.device = properties.name
		self.memory = properties.total_memory
		self.sms = properties.multi_processor_count
		self.cudacores = self.sms * 128
		self.architecture = f'{properties.major}.{properties.minor}'
		self.dashboard = True

class Image:
	@staticmethod
	def load(path, device='cuda'):
		byte_tensor = torchcodec.decoders.decode_image(path, mode='RGB_ALPHA')
		float_tensor = byte_tensor.to(dtype=torch.float32) / 255.0
		_, h, w = float_tensor.shape
		new_h = (h // 16) * 16
		new_w = (w // 16) * 16
		if h != new_h or w != new_w:
			float_tensor = torchvision.transforms.functional.resize(float_tensor, [new_h, new_w], antialias=True)

		return float_tensor.unsqueeze(0).to(device)

	@staticmethod
	def save(tensor, path):
		cpu_tensor = tensor.detach().cpu().squeeze(0).clamp(0.0, 1.0)
		byte_tensor = (cpu_tensor * 255.0).to(dtype=torch.uint8)
		byte_tensor = byte_tensor.permute(1, 2, 0) # from [C,H,W] to [H,W,C]
		numpy_array = byte_tensor.numpy()
		import PIL
		img = PIL.Image.fromarray(numpy_array, mode='RGBA')
		img.save(path)

	@staticmethod
	def downscale(tensor, scale_factor=0.5):
		_, _, original_h, original_w = tensor.shape
		low_res_h = int(original_h * scale_factor)
		low_res_w = int(original_w * scale_factor)
		low_res_tensor = torchvision.transforms.functional.resize(
			tensor,
			[low_res_h, low_res_w],
			interpolation = torchvision.transforms.functional.InterpolationMode.NEAREST
		)
		return low_res_tensor

class Evaluation:
		@staticmethod
		def fold_16ch(tensor_hr, tensor_lr):
			_, channels, h_lr, w_lr = tensor_lr.shape
			hr_grid = tensor_hr.view(1, channels, h_lr, 2, w_lr, 2)
			hr_permuted = hr_grid.permute(0, 2, 4, 3, 5, 1)
			target_16ch = hr_permuted.reshape(1, h_lr, w_lr, 16).permute(0, 3, 1, 2)
			lr_base_16ch = tensor_lr.repeat(1, 4, 1, 1)
			target_velocity_vectors = target_16ch - lr_base_16ch
			return target_velocity_vectors

class UpscaleNetwork(torch.nn.Module):
	def __init__(self):
		super().__init__()
		self.net = torch.nn.Sequential(
			torch.nn.Conv2d(4, 32, kernel_size=3, padding=1),
			torch.nn.ReLU(),
			torch.nn.Conv2d(32, 32, kernel_size=3, padding=1),
			torch.nn.ReLU(),
			torch.nn.Conv2d(32, 144, kernel_size=3, padding=1)
		)
	def forward(self, x):
		return self.net(x)

class HardwareBuffer:
	@staticmethod
	def pack_fp32_to_e4m3_u32(tensor_16ch):
		tensor_hwc = tensor_16ch.squeeze(0).permute(1, 2, 0)
		h, w, _ = tensor_hwc.shape
		grouped_channels = tensor_hwc.view(h, w, 4, 4)
		clamped = torch.clamp(grouped_channels, -448.0, 448.0)
		sign = torch.where(clamped < 0, 1, 0)
		abs_val = torch.abs(clamped)
		exponent = torch.floor(torch.log2(abs_val + 1e-8))+7
		exponent = torch.clamp(exponent, 0, 15).int()
		mantissa = torch.floor((abs_val / (2** (exponent.float() -7 + 1e-8)) - 1.0) * 8.0)
		mantissa = torch.clamp(mantissa, 0, 7).int()

		zero_mask = (abs_val == 0)
		exponent[zero_mask] = 0
		mantissa[zero_mask] = 0
		
		fp8_bytes = ((sign << 7) | (exponent << 3) | mantissa).to(torch.int32)
		
		packed_int32 = (
			(fp8_bytes[:,:,:,0] << 0) |
			(fp8_bytes[:,:,:,1] << 8) |
			(fp8_bytes[:,:,:,2] << 16)|
			(fp8_bytes[:,:,:,3] << 24)
		)
		return packed_int32.to(torch.uint32)

class Inference:
	@staticmethod
	def unfold_16ch_to_hr(tensor_lr, predicted_16ch_vectors):
		lr_base_16ch = tensor_lr.repeat(1, 4, 1, 1)
		reconstructed_subpixel = lr_base_16ch + predicted_16ch_vectors
		b, _, h_lr, w_lr = tensor_lr.shape
		spatial_grid = reconstructed_subpixel.permute(0, 2, 3, 1).view(b, h_lr, w_lr, 2, 2, 4)
		spatial_grid = spatial_grid.permute(0, 5, 1, 3, 2, 4)
		tensor_hr_reconstructed = spatial_grid.reshape(b, 4, h_lr * 2, w_lr * 2)
		return tensor_hr_reconstructed

class HardwareGating:
	@staticmethod
	def continuous_lerp_prediction(predicted_vectors, raw_alpha_mask):
		smooth_mask = torch.clamp(raw_alpha_mask, 0.0, 1.0)
		hard_mask = torch.where(smooth_mask >= 0.5, 1.0 , 0.0)
		blend_weight = torch.lerp(smooth_mask, hard_mask, torch.abs(smooth_mask - 0.5)*2)
		predicated_vectors = predicted_vectors * blend_weight

		return predicated_vectors, blend_weight
	@staticmethod
	def gate_logic(lr_tensor, target_velocity_vectors):
		lr_mono = torch.mean(lr_tensor, dim=1, keepdim=True)
		# structural edge deltas by shifting the image 1 pixel horizontally
		edge_delta = torch.abs(lr_mono[:,:,:,:-1] - lr_mono[:,:,:, 1:])
		mock_alpha_mask = torch.nn.functional.pad(edge_delta, (0, 1, 0, 0), 'constant', 0.0)
		mock_alpha_mask = torch.clamp(mock_alpha_mask * 8.0, 0.0, 1.0)
		gated_velocity_vectors, blend_weights = HardwareGating.continuous_lerp_prediction(
			target_velocity_vectors,
			mock_alpha_mask
		)
		zero_count = torch.sum(blend_weights == 0.0).item()
		total_count = blend_weights.numel()
		print(f'   -> Gating Coverage: Collapsed {zero_count}/{total_count} subpixel coordinates to 0.0')
		return gated_velocity_vectors

class KPNEmulator:
	@staticmethod
	def apply_3x3_kernel(tensor_lr, predicted_kpn_weights):
		b, c, h, w = tensor_lr.shape
		lr_unfolded = torch.nn.functional.unfold(tensor_lr, kernel_size=3, padding=1)
		lr_unfolded = lr_unfolded.view(b, c, 9, h * w)

		weights = predicted_kpn_weights.view(b, 16, 9, h * w)
		channel_indicies = torch.tensor([0, 1, 2, 3] * 4, device=tensor_lr.device)

		spatial_neighbors = lr_unfolded[:, channel_indicies, :, :]
		tensor_16ch_filtered = torch.sum(spatial_neighbors * weights, dim=2)

		return tensor_16ch_filtered.view(b, 16, h, w)

# INITIALIZE ENGINE MODEL :: EXECUTION
if TENSOR :
	model = UpscaleNetwork().to('cuda')
	optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)

	weight_file = pathlib.Path(PATH['checkpoint'])
	if weight_file.exists():
		model.load_state_dict(torch.load(weight_file, map_location='cuda'))
		print('checkpoint loaded\n')

	# load reference # TODO: data.set.<id>.[]
	testimage = Image.load(PATH['input'])
	lr_tensor = Image.downscale(testimage)

	target_velocity_vectors = Evaluation.fold_16ch(testimage, lr_tensor)

	for step in range(1, 201): # simulating 200 runs
		# Forward Pass
		predicted_144ch_weights = model(lr_tensor)
		predicted_16ch_vectors = KPNEmulator.apply_3x3_kernel(lr_tensor, predicted_144ch_weights)

		loss = torch.nn.functional.mse_loss(predicted_16ch_vectors, target_velocity_vectors)

		optimizer.zero_grad()
		loss.backward()
		optimizer.step()
		if step % 5 == 0 or step == 1:
			print(f'   -> Step [{step:02d}/200] | Live Telemetry Loss: {loss.item():.6f}')

	torch.save(model.state_dict(), PATH['checkpoint'])
	print('\ncheckpoint saved\n')
	# Inference
	model.eval()
	with torch.no_grad():
		inference_weights = model(lr_tensor)
		filtered_16ch_prediction = KPNEmulator.apply_3x3_kernel(lr_tensor, inference_weights)
		gated_16ch_prediction = HardwareGating.gate_logic(lr_tensor, filtered_16ch_prediction)
		final_reconstructed_frame = Inference.unfold_16ch_to_hr(lr_tensor, gated_16ch_prediction)

	output_img_path = pathlib.Path(PATH['output'])
	Image.save(final_reconstructed_frame, output_img_path)
	print('')
	# ONNX
	onnx_output_path = pathlib.Path(PATH['model'])	

	h_dim = torch.export.Dim("height", min=16, max=4096)
	w_dim = torch.export.Dim("width", min=16, max=4096)

	canvas_shapes = {2: h_dim, 3: w_dim}
	
	torch.onnx.export(
		model,                         				# The trained neural net module
		(lr_tensor,),                   			# Passed as a clean input tuple
		onnx_output_path,              				# Target file destination path on disk
		export_params=True,            				# Store the trained weight matrices directly inside the file
		opset_version=18,              				# Modern standard ONNX operator set compatibility specification
		input_names=['input_lr'],     				# The entrypoint buffer name your JS code will bind to
		output_names=['output_kpn'],  				# The output array name your JS code will receive
		dynamic_shapes={'x': canvas_shapes} 		# Modern PyTorch 2.x dynamic shape registration # TODO: adjust model forward namespace & match
	)
	torch.cuda.empty_cache()

	import onnx

	model_out = onnx.load(str(onnx_output_path))
	model_out.graph.name = 'spatial-frame-reconstruction'
	model_out.model_version = 1
	for node in model_out.graph.node:
		keep = [item for item in node.metadata_props
				if item.key != "pkg.torch.onnx.stack_trace"]
		del node.metadata_props[:]
		node.metadata_props.extend(keep)
	onnx.save(
		model_out,
		str(onnx_output_path),
		save_as_external_data=False,
	)